/* Copyright (c) 2008-2015, Avian Contributors

   Permission to use, copy, modify, and/or distribute this software
   for any purpose with or without fee is hereby granted, provided
   that the above copyright notice and this permission notice appear
   in all copies.

   There is NO WARRANTY for this software.  See license.txt for
   details. */

package avian;

public class ClassAddendum extends Addendum {
  public Object[] interfaceTable;
  public InnerClassReference[] innerClassTable;
  /**
   * If this value is negative, all the methods in VMClass.methodTable
   * were declared in that class.  Otherwise, only the first
   * declaredMethodCount methods in that table were declared in that
   * class, while the rest were declared in interfaces implemented or
   * extended by that class.
   */
  public int declaredMethodCount;

  public byte[] enclosingClass;

  public Pair enclosingMethod;
}
